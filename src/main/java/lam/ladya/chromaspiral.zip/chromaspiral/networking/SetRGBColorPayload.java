package lam.ladya.chromaspiral.networking;

import lam.ladya.chromaspiral.ChromaSpiral;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record SetRGBColorPayload(BlockPos pos, int color)
        implements CustomPacketPayload {

    // 🔑 ID lives HERE in this Forge version
    public static final ResourceLocation ID =
    		ResourceLocation.fromNamespaceAndPath(ChromaSpiral.MODID,
            		"set_rgb_color"
            		);

    // 🔑 TYPE is how Forge identifies the packet
    public static final Type<SetRGBColorPayload> TYPE =
            new Type<>(ID);

    // 🔑 CODEC is how Forge serializes/deserializes
    public static final StreamCodec<FriendlyByteBuf, SetRGBColorPayload> CODEC =
            StreamCodec.of(
                    (buf, payload) -> {
                        buf.writeBlockPos(payload.pos());
                        buf.writeInt(payload.color());
                    },
                    buf -> new SetRGBColorPayload(
                            buf.readBlockPos(),
                            buf.readInt()
                    )
            );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
