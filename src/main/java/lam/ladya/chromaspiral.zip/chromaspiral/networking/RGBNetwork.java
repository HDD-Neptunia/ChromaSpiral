package lam.ladya.chromaspiral.networking;

import lam.ladya.chromaspiral.ChromaSpiral;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.common.ClientboundCustomPayloadPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.PayloadRegistry;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.minecraftforge.network.PacketDistributor;

public class RGBNetwork {

    public static final ResourceLocation SET_RGB_COLOR_ID =
            ResourceLocation.fromNamespaceAndPath(ChromaSpiral.MODID,
            		"set_rgb_color"
            		);

    public static void register() {

    	PayloadRegistrar.registerClientbound(
    	        SetRGBColorPayload.TYPE,
    	        SetRGBColorPayload.CODEC,
    	        (payload, ctx) -> {
    	            ctx.enqueueWork(() -> {
    	                if (payload.color() == -1) {
    	                    RGBClientColorCache.remove(payload.pos());
    	                } else {
    	                    RGBClientColorCache.setColor(payload.pos(), payload.color());
    	                }

    	                var level = Minecraft.getInstance().level;
    	                if (level != null) {
    	                    level.sendBlockUpdated(
    	                            payload.pos(),
    	                            level.getBlockState(payload.pos()),
    	                            level.getBlockState(payload.pos()),
    	                            3
    	                    );
    	                }
    	            });
    	        }
    	);

    }

    public static void sendToTracking(Level level, BlockPos pos, int color) {
        if (!(level instanceof ServerLevel serverLevel)) return;

        SetRGBColorPayload payload = new SetRGBColorPayload(pos, color);

        serverLevel.getChunkSource()
                .chunkMap
                .getPlayers(new ChunkPos(pos), false)
                .forEach(player ->
                        player.connection.send(
                                new ClientboundCustomPayloadPacket(payload)
                        )
                );
    }
}


