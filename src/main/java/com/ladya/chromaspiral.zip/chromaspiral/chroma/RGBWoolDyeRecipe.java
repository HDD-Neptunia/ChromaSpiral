package com.ladya.chromaspiral.chroma;

import com.ladya.chromaspiral.ModBlocks;
import com.ladya.chromaspiral.blocks.ModRecipeSerializers;

import net.minecraft.core.NonNullList;
import net.minecraft.core.RegistryAccess;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;



public class RGBWoolDyeRecipe extends CustomRecipe {

    public RGBWoolDyeRecipe(ResourceLocation id) {
        super(id, CraftingBookCategory.MISC);
    }

    @Override
    public boolean matches(CraftingContainer container, Level level) {
        boolean foundWool = false;
        boolean foundDye = false;

        for (int i = 0; i < container.getContainerSize(); i++) {
            ItemStack stack = container.getItem(i);
            if (stack.isEmpty()) continue;

            if (stack.is(ModBlocks.RGB_WOOL_ITEM.get())) {
                foundWool = true; // ✅ allow many
            } else if (stack.getItem() instanceof DyeItem) {
                foundDye = true;
            } else {
                return false;
            }
        }

        return foundWool && foundDye;
    }


    @Override
    public ItemStack assemble(CraftingContainer container, RegistryAccess access) {
        int woolCount = 0;
        int r = 0, g = 0, b = 0, dyeCount = 0;

        for (int i = 0; i < container.getContainerSize(); i++) {
            ItemStack stack = container.getItem(i);
            if (stack.isEmpty()) continue;

            if (stack.is(ModBlocks.RGB_WOOL_ITEM.get())) {
                woolCount += stack.getCount(); // ✅ sum all wool
            } else if (stack.getItem() instanceof DyeItem dye) {
                float[] c = dye.getDyeColor().getTextureDiffuseColors();
                r += (int)(c[0] * 255);
                g += (int)(c[1] * 255);
                b += (int)(c[2] * 255);
                dyeCount++;
            }
        }

        if (woolCount == 0 || dyeCount == 0) return ItemStack.EMPTY;

        r /= dyeCount;
        g /= dyeCount;
        b /= dyeCount;

        int color = (r << 16) | (g << 8) | b;

        ItemStack result = new ItemStack(ModBlocks.RGB_WOOL_ITEM.get(), woolCount);
        result.getOrCreateTag().putInt("Color", color);

        return result;
    }

    
    @Override
    public ItemStack getResultItem(RegistryAccess access) {
        return new ItemStack(ModBlocks.RGB_WOOL_ITEM.get());
    }


    @Override
    public boolean canCraftInDimensions(int w, int h) {
        return w * h >= 2;
    }

    @Override
    public NonNullList<ItemStack> getRemainingItems(CraftingContainer inv) {
        NonNullList<ItemStack> remaining =
                NonNullList.withSize(inv.getContainerSize(), ItemStack.EMPTY);

        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);

            if (stack.isEmpty()) continue;

            // RGB Wool: consume ALL of it
            if (stack.is(ModBlocks.RGB_WOOL_ITEM.get())) {
                continue;
            }

            // Dyes: consume exactly ONE
            if (stack.getItem() instanceof DyeItem) {
                if (stack.getCount() > 1) {
                    ItemStack leftover = stack.copy();
                    leftover.shrink(1); //remove ONE dye
                    remaining.set(i, leftover);
                }
                continue;
            }
        }

        return remaining;
    }



    @Override
    public RecipeSerializer<?> getSerializer() {
        return ModRecipeSerializers.RGB_WOOL_DYE.get();
    }
}

