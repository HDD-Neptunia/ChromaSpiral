package com.ladya.chromaspiral.chroma;


public record RGBColor(int r, int g, int b) {}
