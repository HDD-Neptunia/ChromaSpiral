package com.ladya.chromaspiral.station;

import org.joml.Matrix4f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.InventoryMenu;

public class ChromaDyeTableRenderer implements BlockEntityRenderer<ChromaDyeTableBlockEntity> {

public ChromaDyeTableRenderer(BlockEntityRendererProvider.Context context) {
// nothing yet
}

@SuppressWarnings("removal")
@Override
public void render(
        ChromaDyeTableBlockEntity be,
        float partialTick,
        PoseStack poseStack,
        MultiBufferSource buffer,
        int packedLight,
        int packedOverlay
) {
    int water = be.getWaterLevel();
    if (water <= 0) return;

    poseStack.pushPose();

    // Height calculation
    float minY = 4f / 16f;
    float maxY = 13f / 16f;
    float level = minY + (water / 8f) * (maxY - minY);

    float inset = 2f / 16f;

    VertexConsumer vc = buffer.getBuffer(RenderType.translucent());

    TextureAtlasSprite sprite = Minecraft.getInstance()
    	.getTextureAtlas(InventoryMenu.BLOCK_ATLAS)
    	.apply(new ResourceLocation("minecraft:block/water_still"));


    Matrix4f mat = poseStack.last().pose();

    vc.vertex(mat, inset, level, inset)
	    .color(255, 255, 255, 200)
	    .uv(sprite.getU0(), sprite.getV0())
	    .uv2(packedLight)
	    .normal(0f, 1f, 0f)
	    .endVertex();


    vc.vertex(mat, inset, level, inset)
	    .color(255, 255, 255, 200)
	    .uv(sprite.getU0(), sprite.getV0())
	    .uv2(packedLight)
	    .normal(0f, 1f, 0f)
	    .endVertex();


    vc.vertex(mat, 1 - inset, level, inset)
	    .color(255, 255, 255, 200)
	    .uv(sprite.getU0(), sprite.getV0())
	    .uv2(packedLight)
	    .normal(0f, 1f, 0f)
	    .endVertex();


    vc.vertex(mat, inset, level, inset)
	    .color(255, 255, 255, 200)
	    .uv(sprite.getU0(), sprite.getV0())
	    .uv2(packedLight)
	    .normal(0f, 1f, 0f)
	    .endVertex();

    poseStack.popPose();
}

}
