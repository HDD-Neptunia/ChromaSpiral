package com.ladya.chromaspiral.station;

import net.minecraft.world.entity.player.Player;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.items.SlotItemHandler;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.DyeItem;


public class ChromaDyeOutputSlot extends SlotItemHandler {

    private final IItemHandler handler;
    private final ChromaDyeTableBlockEntity blockEntity;

    public ChromaDyeOutputSlot(IItemHandler handler, ChromaDyeTableBlockEntity blockEntity, int index, int x, int y) {
        super(handler, index, x, y);
        this.handler = handler;
        this.blockEntity = blockEntity;
    }


    @Override
    public boolean mayPickup(Player player) {
        return blockEntity.getWaterLevel() > 0;
    }
    
    @Override
    public void onTake(Player player, ItemStack stack) {

        if (player.level().isClientSide) {
            super.onTake(player, stack);
            return;
        }

        ItemStackHandler stacks = blockEntity.getItemHandler();

        // 🔥 STOP preview regeneration for this tick
        //blockEntity.setSuppressPreview(true);


        // 2️⃣ Consume ONE dye
        for (int i = ChromaDyeTableBlockEntity.FIRST_DYE_SLOT;
             i <= ChromaDyeTableBlockEntity.LAST_DYE_SLOT;
             i++) {

            ItemStack dye = stacks.getStackInSlot(i);
            if (dye.getItem() instanceof DyeItem) {
                dye.shrink(1);
                stacks.setStackInSlot(i, dye.isEmpty() ? ItemStack.EMPTY : dye);
                break;
            }
        }

        // 3️⃣ Consume wool
        stacks.setStackInSlot(
            ChromaDyeTableBlockEntity.WOOL_SLOT,
            ItemStack.EMPTY
        );

        // 4️⃣ Clear output preview
        stacks.setStackInSlot(
            ChromaDyeTableBlockEntity.OUTPUT_SLOT,
            ItemStack.EMPTY
        );

        blockEntity.setChanged();

        // 5️⃣ Let vanilla finish pickup
        super.onTake(player, stack);

        // 🔓 Re-enable preview next tick
        //blockEntity.setSuppressPreview(false);

    }


    

    @Override
    public boolean mayPlace(ItemStack stack) {
        return false;
    }

    @Override
    public void onQuickCraft(ItemStack oldStack, ItemStack newStack) {
        // no-op
    }


}
